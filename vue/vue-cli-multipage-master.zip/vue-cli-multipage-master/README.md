# vue-cli多页面应用
> A Vue.js project

### 文章地址：http://www.cnblogs.com/fengyuqing/p/vue_cli_webpack.html

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
